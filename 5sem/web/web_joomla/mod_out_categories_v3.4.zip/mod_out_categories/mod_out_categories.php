<?php

/**
 * @package Joomla.Site
 * @subpackage mod_out_articles
 *
 * @copyright Copyright (C) 2005 - 2016 Open Source Matters,
 * Inc. All rights reserved.
 * @license GNU General Public License version 2 or later;
 * see LICENSE.txt
 */

    defined('_JEXEC') or die;

    use Joomla\CMS\Factory;

    // Получаем объект базы данных
    $db = Factory::getDbo();
    $query = $db->getQuery(true);

    //Формируем запрос
    $query->select([
        $db->quoteName('c.title'),
        $db->quoteName('u.name'),
        $db->quoteName('c.level')
    ])
        ->from($db->quoteName('#__categories', 'c'))
        ->join( 'INNER', $db->quoteName('#__users', 'u') .
        'ON' . $db->quoteName('u.id') . '=' . $db->quoteName('c.created_user_id') )
        ->order($db->quoteName('u.name'));

    // Предварительно устанавливаем текст запроса
    $db->setQuery($query);

    // Выолняем запрос
    $db->execute();

    // Получаем результат - индексированный массив, 
    // каждый элемент которого является объект.
    $data = $db->loadObjectList();

    foreach($data as $row)
    {
        echo "<p>" 
        . htmlspecialchars($row->title) . " - " 
        . htmlspecialchars($row->name) . " - " 
        . htmlspecialchars($row->level) 
        . "</p>";
    }
?>

