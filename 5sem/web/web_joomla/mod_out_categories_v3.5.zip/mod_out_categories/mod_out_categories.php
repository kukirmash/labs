<?php

/**
 * @package Joomla.Site
 * @subpackage mod_out_articles
 *
 * @copyright Copyright (C) 2005 - 2016 Open Source Matters,
 * Inc. All rights reserved.
 * @license GNU General Public License version 2 or later;
 * see LICENSE.txt
 */

    defined('_JEXEC') or die;

    use Joomla\CMS\Factory;

    // Получаем объект базы данных
    $db = Factory::getDbo();
    $query = $db->getQuery(true);

    //Формируем запрос
    $query->select([
        $db->quoteName('c.title'),
        $db->quoteName('u.name'),
        $db->quoteName('c.level')
    ])
        ->from($db->quoteName('#__categories', 'c'))
        ->join( 'INNER', $db->quoteName('#__users', 'u') .
        'ON' . $db->quoteName('u.id') . '=' . $db->quoteName('c.created_user_id') )
        ->order($db->quoteName('u.name'));

    // Предварительно устанавливаем текст запроса
    $db->setQuery($query);

    // Выолняем запрос
    $db->execute();

    // Получаем результат - индексированный массив, 
    // каждый элемент которого является объект.
    $data = $db->loadObjectList();

    if (!empty($data))
    {
        echo '<table border="1" cellpadding="5" cellspacing="0">';
        echo '<tr><th>Название</th><th>Автор</th><th>Уровень вложенности</th></tr>';

        foreach ($data as $row)
        {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row->title) . '</td>';
            echo '<td>' . htmlspecialchars($row->name) . '</td>';
            echo '<td>' . htmlspecialchars($row->level) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } 
    else
    {
        echo '<p>Нет данных для отображения.</p>';
    }
?>
